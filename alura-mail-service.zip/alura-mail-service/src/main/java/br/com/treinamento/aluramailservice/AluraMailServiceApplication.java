package br.com.treinamento.aluramailservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AluraMailServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AluraMailServiceApplication.class, args);
	}
}
